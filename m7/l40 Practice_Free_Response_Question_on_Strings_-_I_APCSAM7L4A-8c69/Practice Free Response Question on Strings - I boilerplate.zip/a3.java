// Import necessary classes for input handling
// - 'Scanner' class is used to take input from the user

// Define the class 'ReplaceSubstring' for substring replacement logic

// Method to replace all occurrences of oldSub with newSub in the given string (str)
// - Handles edge cases like null or empty inputs
// - Uses a StringBuilder for efficient string manipulation
// - Loops through the string, finding each occurrence of oldSub using indexOf
// - Appends parts of the string before each found substring and replaces it with newSub
// - Appends the remaining portion of the string after the last replacement
// - Returns the final string after all replacements

// Main method - Entry point of the program
// - Create an instance of the ReplaceSubstring class to access the replaceSubstring method
// - Prompt the user to input the main string (str)
// - Prompt the user to input the substring to be replaced (oldSub)
// - Prompt the user to input the new substring (newSub)
// - Call the replaceSubstring method to perform the replacements
// - Print the modified string after replacements

// IMPORTANT: Save this file as **ReplaceSubstring.java** because the class name 'ReplaceSubstring' matches the filename
