// Import necessary classes for input handling
// - 'Scanner' class to take input from the user

// Define the class 'StringFrequncyII' for substring frequency counting logic

// Method to count occurrences of a substring (sub) in the main string (str)
// - Uses a loop to find the index of the substring in the string
// - Each time the substring is found, increment the count and move the index forward by the length of the substring
// - Return the total count of the substring occurrences

// Main method - Entry point of the program
// - Create an instance of the StringFrequncyII class to access the countSubstring method
// - Prompt the user to enter the main string (str)
// - Prompt the user to enter the substring (sub)
// - Call the countSubstring method to count the occurrences of sub in str
// - Print the result showing how many times the substring appears

// IMPORTANT: Save this file as **StringFrequncyII.java** because the class name 'StringFrequncyII' matches the filename
