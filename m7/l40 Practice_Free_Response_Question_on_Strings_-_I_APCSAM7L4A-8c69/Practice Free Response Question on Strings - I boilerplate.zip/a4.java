// Import necessary classes for input handling
// - 'Scanner' class is used to take input from the user

// Define the class 'CompareStrings' for string comparison logic

// Method to compare two strings lexicographically
// - It compares characters of both strings one by one
// - If the characters at the same position are different, it returns the difference
// - If the characters are the same, it compares the lengths of the two strings
// - Returns a positive value if the first string is lexicographically larger, 
//   a negative value if the first string is smaller, and 0 if they are equal

// Main method - Entry point of the program
// - Create an instance of the CompareStrings class to access the compareStrings method
// - Prompt the user to input two strings (str1 and str2)
// - Call the compareStrings method to compare the strings
// - Print the result based on the comparison:
//   - 'The strings are equal' if the result is 0
//   - 'The first string is lexicographically smaller' if the result is negative
//   - 'The first string is lexicographically larger' if the result is positive

// IMPORTANT: Save this file as **CompareStrings.java** because the class name 'CompareStrings' matches the filename
