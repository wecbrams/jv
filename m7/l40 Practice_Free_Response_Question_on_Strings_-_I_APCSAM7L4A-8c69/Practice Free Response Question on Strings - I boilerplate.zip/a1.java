// Import necessary classes for input handling
// - 'Scanner' class to take input from the user

// Define the class 'StringFrequencyI' for substring checking logic

// Method to check if str2 is a substring of str1
// - Uses indexOf to find the position of str2 in str1
// - Returns true if str2 is found in str1 (index >= 0), otherwise returns false

// Main method - Entry point of the program
// - Create an instance of the StringFrequencyI class to access the isSubstring method
// - Prompt the user to enter the main string (str1)
// - Prompt the user to enter the substring (str2)
// - Call the isSubstring method to check if str2 is a substring of str1
// - Print the result (true or false) based on the presence of str2 in str1

// IMPORTANT: Save this file as **StringFrequencyI.java** because the class name 'StringFrequencyI' matches the filename
